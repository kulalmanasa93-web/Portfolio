/**
 * ============================================================================
 * PORTFOLIO JAVASCRIPT — MANASA KULAL
 * Clean, Modular, Interactive & Accessible
 * ============================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // --------------------------------------------------------------------------
  // 1. Theme Toggle (Dark & Light Mode with LocalStorage persistence)
  // --------------------------------------------------------------------------
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const themeIcon = themeToggleBtn ? themeToggleBtn.querySelector('i') : null;
  const rootElement = document.documentElement;

  // Determine initial theme
  const savedTheme = localStorage.getItem('portfolio-theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const initialTheme = savedTheme || (prefersDark ? 'dark' : 'light');

  function applyTheme(theme) {
    rootElement.setAttribute('data-theme', theme);
    localStorage.setItem('portfolio-theme', theme);

    if (themeIcon) {
      if (theme === 'dark') {
        themeIcon.className = 'fa-solid fa-sun';
        themeToggleBtn.setAttribute('aria-label', 'Switch to light mode');
      } else {
        themeIcon.className = 'fa-solid fa-moon';
        themeToggleBtn.setAttribute('aria-label', 'Switch to dark mode');
      }
    }
  }

  // Set default theme on page load
  applyTheme(initialTheme);

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const currentTheme = rootElement.getAttribute('data-theme') || 'dark';
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      applyTheme(newTheme);
      showToast(`Switched to ${newTheme} theme`, 'info');
    });
  }

  // --------------------------------------------------------------------------
  // 2. Dynamic Typing Text Effect
  // --------------------------------------------------------------------------
  const typingElement = document.getElementById('typingText');
  const roles = [
    'AI & ML Specialist',
    'Python & Web Developer',
    'B.E. Computer Science Student',
    'Intelligent Systems Enthusiast',
    'Algorithmic Problem Solver'
  ];
  let roleIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  const typeSpeed = 90;
  const deleteSpeed = 45;
  const delayBetweenWords = 1800;

  function typeEffect() {
    if (!typingElement) return;

    const currentRole = roles[roleIndex];

    if (isDeleting) {
      typingElement.textContent = currentRole.substring(0, charIndex - 1);
      charIndex--;
    } else {
      typingElement.textContent = currentRole.substring(0, charIndex + 1);
      charIndex++;
    }

    let currentSpeed = isDeleting ? deleteSpeed : typeSpeed;

    if (!isDeleting && charIndex === currentRole.length) {
      currentSpeed = delayBetweenWords;
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      roleIndex = (roleIndex + 1) % roles.length;
      currentSpeed = 350;
    }

    setTimeout(typeEffect, currentSpeed);
  }

  typeEffect();

  // --------------------------------------------------------------------------
  // 3. Mobile Navigation Menu
  // --------------------------------------------------------------------------
  const mobileNavToggle = document.getElementById('mobileNavToggle');
  const navLinks = document.getElementById('navLinks');

  if (mobileNavToggle && navLinks) {
    mobileNavToggle.addEventListener('click', () => {
      const isOpen = navLinks.classList.toggle('open');
      const icon = mobileNavToggle.querySelector('i');
      if (icon) {
        icon.className = isOpen ? 'fa-solid fa-xmark' : 'fa-solid fa-bars';
      }
      mobileNavToggle.setAttribute('aria-expanded', isOpen);
    });

    // Close mobile nav when clicking any nav link
    navLinks.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        const icon = mobileNavToggle.querySelector('i');
        if (icon) icon.className = 'fa-solid fa-bars';
        mobileNavToggle.setAttribute('aria-expanded', 'false');
      });
    });

    // Close when clicking outside
    document.addEventListener('click', (e) => {
      if (!navLinks.contains(e.target) && !mobileNavToggle.contains(e.target)) {
        navLinks.classList.remove('open');
        const icon = mobileNavToggle.querySelector('i');
        if (icon) icon.className = 'fa-solid fa-bars';
        mobileNavToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // --------------------------------------------------------------------------
  // 4. ScrollSpy: Highlight Active Nav Link
  // --------------------------------------------------------------------------
  const sections = document.querySelectorAll('section[id]');
  const navItems = document.querySelectorAll('.nav-link[href^="#"]');

  function updateActiveNavLink() {
    const scrollY = window.pageYOffset;

    sections.forEach(current => {
      const sectionHeight = current.offsetHeight;
      const sectionTop = current.offsetTop - 120;
      const sectionId = current.getAttribute('id');

      if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
        navItems.forEach(item => {
          item.classList.remove('active');
          if (item.getAttribute('href') === `#${sectionId}`) {
            item.classList.add('active');
          }
        });
      }
    });
  }

  window.addEventListener('scroll', updateActiveNavLink, { passive: true });

  // --------------------------------------------------------------------------
  // 5. Back to Top Button
  // --------------------------------------------------------------------------
  const backToTopBtn = document.getElementById('backToTopBtn');

  if (backToTopBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 350) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    }, { passive: true });

    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }

  // --------------------------------------------------------------------------
  // 6. Skills Category Filter
  // --------------------------------------------------------------------------
  const skillFilterBtns = document.querySelectorAll('.filter-btn');
  const skillCards = document.querySelectorAll('.skill-card');

  skillFilterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      skillFilterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.getAttribute('data-filter');

      skillCards.forEach(card => {
        const category = card.getAttribute('data-category');
        if (filter === 'all' || category === filter) {
          card.style.display = 'flex';
          setTimeout(() => { card.style.opacity = '1'; card.style.transform = 'scale(1)'; }, 10);
        } else {
          card.style.opacity = '0';
          card.style.transform = 'scale(0.95)';
          setTimeout(() => { card.style.display = 'none'; }, 200);
        }
      });
    });
  });

  // --------------------------------------------------------------------------
  // 7. Project Details Modal Architecture & Deep-Dive
  // --------------------------------------------------------------------------
  const projectDetailsModal = document.getElementById('projectModal');
  const modalCloseBtn = document.getElementById('modalCloseBtn');
  const modalContentArea = document.getElementById('modalContentArea');

  const projectData = {
    translation: {
      title: 'Language Translation Tool',
      subtitle: 'Python-based AI Translation Pipeline',
      badge: 'Python • Artificial Intelligence • NLP',
      overview: 'A robust natural language processing application created in Python to demonstrate neural and rule-based linguistic transformation across multiple languages.',
      features: [
        'Bidirectional sentence parsing and translation algorithms.',
        'Clean tokenization and text preprocessing modules to handle diverse character encodings.',
        'Extensible pipeline design allowing integration of contemporary AI models and APIs.',
        'User-friendly CLI / script execution interface for batch and single-query translations.'
      ],
      techStack: ['Python 3.x', 'AI / ML Algorithms', 'Natural Language Processing (NLP)', 'Text Encodings / UTF-8'],
      repoPlaceholder: 'https://github.com/manasa-kulal/language-translation-tool'
    },
    chatbot: {
      title: 'General FAQ Chatbot',
      subtitle: 'Intelligent Query Retrieval with Cosine Similarity',
      badge: 'Python • TF-IDF • Cosine Similarity • Gradio',
      overview: 'An automated conversational assistant capable of understanding user queries and mapping them accurately to verified knowledge-base responses using statistical NLP techniques.',
      features: [
        'Preprocessing pipeline including lowercasing, stop-word removal, and lemmatization.',
        'TF-IDF (Term Frequency - Inverse Document Frequency) vectorization of query corpora.',
        'Cosine Similarity mathematical ranking algorithm to match user questions with optimal answers.',
        'Interactive, responsive web user interface powered by Gradio for real-time testing and user feedback.'
      ],
      techStack: ['Python', 'TF-IDF Vectorizer', 'Cosine Similarity', 'Gradio UI', 'NLTK / Scikit-Learn'],
      repoPlaceholder: 'https://github.com/manasa-kulal/faq-chatbot'
    },
    blood: {
      title: 'Blood Management System',
      subtitle: 'Web-based Donor & Inventory Coordination Portal',
      badge: 'PHP • MySQL • XAMPP • HTML • CSS • JavaScript',
      overview: 'A full-stack web application designed to connect voluntary blood donors with hospital requisitions, tracking blood unit availability in real-time.',
      features: [
        'Relational database architecture built with MySQL (via XAMPP) for donor records, recipient requests, and stock tracking.',
        'Dynamic search and filtering by blood group (A+, B+, O+, AB+, etc.) and location.',
        'Comprehensive frontend validation with JavaScript to guarantee accurate donor information input.',
        'Modular PHP backend ensuring secure CRUD (Create, Read, Update, Delete) operations.'
      ],
      techStack: ['PHP', 'MySQL Database', 'XAMPP Server', 'HTML5 & CSS3', 'JavaScript'],
      repoPlaceholder: 'https://github.com/manasa-kulal/blood-management-system'
    }
  };

  window.openProjectModal = function(projectId) {
    const data = projectData[projectId];
    if (!data || !projectDetailsModal || !modalContentArea) return;

    modalContentArea.innerHTML = `
      <div class="modal-header">
        <span class="skill-category-badge" style="margin-bottom: 0.6rem; display: inline-block;">${data.badge}</span>
        <h3 class="modal-title">${data.title}</h3>
        <p class="modal-subtitle">${data.subtitle}</p>
      </div>
      <div class="modal-body">
        <h4>Project Overview</h4>
        <p>${data.overview}</p>

        <h4>Key Engineering Highlights</h4>
        <ul>
          ${data.features.map(f => `<li>${f}</li>`).join('')}
        </ul>

        <h4>Technology Stack</h4>
        <div class="project-tags" style="margin-bottom: 1.5rem;">
          ${data.techStack.map(t => `<span class="project-tag">${t}</span>`).join('')}
        </div>

        <div class="modal-actions">
          <a href="${data.repoPlaceholder}" target="_blank" rel="noopener" class="btn btn-primary" onclick="handlePlaceholderClick(event, 'GitHub Repository')">
            <i class="fa-brands fa-github"></i> View GitHub Repository
          </a>
          <button class="btn btn-secondary" onclick="closeModal()">
            Close Details
          </button>
        </div>
      </div>
    `;

    projectDetailsModal.classList.add('active');
    document.body.style.overflow = 'hidden';
  };

  window.closeModal = function() {
    if (projectDetailsModal) {
      projectDetailsModal.classList.remove('active');
      document.body.style.overflow = '';
    }
  };

  if (modalCloseBtn) {
    modalCloseBtn.addEventListener('click', closeModal);
  }

  if (projectDetailsModal) {
    projectDetailsModal.addEventListener('click', (e) => {
      if (e.target === projectDetailsModal) closeModal();
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && projectDetailsModal && projectDetailsModal.classList.contains('active')) {
      closeModal();
    }
  });

  // --------------------------------------------------------------------------
  // 8. Contact Form Handling (STRICT EMAIL DRAFT INTEGRATION)
  // --------------------------------------------------------------------------
  const contactForm = document.getElementById('contactForm');
  const recipientEmail = 'kulalmanasa93@gmail.com';

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const nameInput = document.getElementById('formName');
      const emailInput = document.getElementById('formEmail');
      const subjectInput = document.getElementById('formSubject');
      const messageInput = document.getElementById('formMessage');

      let isValid = true;

      // Reset previous error classes
      [nameInput, emailInput, subjectInput, messageInput].forEach(input => {
        if (input && input.parentElement) {
          input.parentElement.classList.remove('has-error');
        }
      });

      // Name Validation
      if (!nameInput.value.trim() || nameInput.value.trim().length < 2) {
        showError(nameInput, 'Please enter your name (at least 2 characters).');
        isValid = false;
      }

      // Email Validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailInput.value.trim() || !emailRegex.test(emailInput.value.trim())) {
        showError(emailInput, 'Please provide a valid email address.');
        isValid = false;
      }

      // Subject Validation
      if (!subjectInput.value.trim()) {
        showError(subjectInput, 'Please provide a subject line.');
        isValid = false;
      }

      // Message Validation
      if (!messageInput.value.trim() || messageInput.value.trim().length < 10) {
        showError(messageInput, 'Please enter a message of at least 10 characters.');
        isValid = false;
      }

      if (!isValid) {
        showToast('Please fix the highlighted form errors.', 'warning');
        return;
      }

      const name = nameInput.value.trim();
      const email = emailInput.value.trim();
      const subject = subjectInput.value.trim();
      const message = messageInput.value.trim();

      // Formulate mailto payload
      const fullSubject = `[Portfolio Contact] ${subject} - from ${name}`;
      const fullBody = `Hi Manasa,\n\nName: ${name}\nEmail: ${email}\n\nMessage:\n${message}\n\nSent via Portfolio Website`;

      const mailtoUri = `mailto:${recipientEmail}?subject=${encodeURIComponent(fullSubject)}&body=${encodeURIComponent(fullBody)}`;

      // Open email client draft
      window.location.href = mailtoUri;

      showToast('Opening your default email client to send message...', 'info');

      // Also display a confirmation modal with 1-click copy option if email app didn't open
      openDraftConfirmationModal(name, email, subject, message);
    });
  }

  function showError(inputEl, msg) {
    if (!inputEl || !inputEl.parentElement) return;
    const group = inputEl.parentElement;
    group.classList.add('has-error');
    const errText = group.querySelector('.form-error');
    if (errText) errText.textContent = msg;
  }

  function openDraftConfirmationModal(name, email, subject, message) {
    if (!modalContentArea || !projectDetailsModal) return;

    const draftText = `To: ${recipientEmail}\nSubject: [Portfolio Contact] ${subject} - from ${name}\n\nHi Manasa,\nName: ${name}\nEmail: ${email}\n\n${message}`;

    modalContentArea.innerHTML = `
      <div class="modal-header">
        <span class="verified-pill" style="margin-bottom: 0.6rem; display: inline-flex;"><i class="fa-solid fa-envelope-open-text"></i> Email Draft Generated</span>
        <h3 class="modal-title">Ready to Send to Manasa</h3>
        <p class="modal-subtitle">Your message draft has been formatted for <strong>${recipientEmail}</strong>.</p>
      </div>
      <div class="modal-body">
        <p>If your system's default email app opened automatically, you can review and click Send there.</p>
        <p>Alternatively, you can copy the drafted text below and paste it into your favorite email client (Gmail, Outlook, etc.):</p>

        <textarea id="copyDraftArea" readonly class="form-textarea" style="height: 140px; font-family: monospace; font-size: 0.85rem; margin-bottom: 1rem;">${draftText}</textarea>

        <div class="modal-actions">
          <button class="btn btn-primary" onclick="copyDraftedMessage()">
            <i class="fa-solid fa-copy"></i> Copy Message to Clipboard
          </button>
          <a href="mailto:${recipientEmail}?subject=${encodeURIComponent(`[Portfolio Contact] ${subject} - from ${name}`)}&body=${encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`)}" class="btn btn-secondary">
            <i class="fa-solid fa-arrow-up-right-from-square"></i> Re-launch Email Client
          </a>
        </div>
      </div>
    `;

    projectDetailsModal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  window.copyDraftedMessage = function() {
    const area = document.getElementById('copyDraftArea');
    if (area) {
      area.select();
      navigator.clipboard.writeText(area.value)
        .then(() => {
          showToast('Drafted message copied to clipboard!', 'success');
        })
        .catch(() => {
          document.execCommand('copy');
          showToast('Drafted message copied to clipboard!', 'success');
        });
    }
  };

  // --------------------------------------------------------------------------
  // 9. Copy Email Address Directly
  // --------------------------------------------------------------------------
  window.copyEmailAddress = function() {
    navigator.clipboard.writeText(recipientEmail)
      .then(() => {
        showToast('Email address copied to clipboard: ' + recipientEmail, 'success');
      })
      .catch(() => {
        showToast('Email address: ' + recipientEmail, 'info');
      });
  };

  // --------------------------------------------------------------------------
  // 10. Placeholder Click Handler (GitHub / Demo links)
  // --------------------------------------------------------------------------
  window.handlePlaceholderClick = function(event, label) {
    const targetUrl = event.currentTarget.getAttribute('href');
    if (!targetUrl || targetUrl.includes('your-username') || targetUrl.includes('placeholder') || targetUrl === '#' || targetUrl.includes('github.com/manasa-kulal')) {
      // It's a placeholder link
      event.preventDefault();
      showToast(`${label} link placeholder. Update with your official URL in index.html!`, 'info');
    }
  };

  // --------------------------------------------------------------------------
  // 11. Toast Notification Helper
  // --------------------------------------------------------------------------
  function showToast(message, type = 'info') {
    let container = document.getElementById('toastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toastContainer';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let icon = 'fa-circle-info';
    if (type === 'success') icon = 'fa-circle-check';
    if (type === 'warning') icon = 'fa-triangle-exclamation';

    toast.innerHTML = `
      <i class="fa-solid ${icon}"></i>
      <span>${message}</span>
    `;

    container.appendChild(toast);

    // Trigger animation
    setTimeout(() => toast.classList.add('show'), 10);

    // Auto remove
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 4200);
  }

  // --------------------------------------------------------------------------
  // 12. Intersection Observer for Scroll Reveals
  // --------------------------------------------------------------------------
  const revealElements = document.querySelectorAll('.reveal');

  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, {
      rootMargin: '0px 0px -50px 0px',
      threshold: 0.15
    });

    revealElements.forEach(el => revealObserver.observe(el));
  } else {
    // Fallback for older browsers
    revealElements.forEach(el => el.classList.add('revealed'));
  }
});
