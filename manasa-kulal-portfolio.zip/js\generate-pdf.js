const fs = require('fs');
const path = require('path');

// Simple pure Node.js PDF generator for standard text
function createPDF(outputPath) {
  const content = [];
  
  function addText(text, x, y, size = 10, isBold = false) {
    const font = isBold ? '/F2' : '/F1';
    // Escape parentheses and backslashes in PDF strings
    const safeText = text.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
    content.push(`BT ${font} ${size} Tf ${x} ${y} Td (${safeText}) Tj ET`);
  }

  function addLine(x1, y1, x2, y2, width = 1, color = '0 0 0') {
    content.push(`${color} RG ${width} w ${x1} ${y1} m ${x2} ${y2} l S`);
  }

  function addRect(x, y, w, h, fillColor = '0.95 0.95 0.95') {
    content.push(`${fillColor} rg ${x} ${y} ${w} ${h} re f`);
  }

  // Top header background
  addRect(0, 740, 612, 52, '0.12 0.1 0.28'); // Deep Purple
  
  // Header Text
  addText('MANASA KULAL', 45, 762, 20, true);
  addText('B.E. Computer Science & Engineering (AI & ML) Student', 45, 747, 10, false);

  // Contact Info bar
  addRect(40, 705, 532, 24, '0.96 0.94 0.99');
  addText('Mangalore, India  |  +91 9483649608  |  kulalmanasa93@gmail.com  |  linkedin.com/in/manasa-kulal-204542434', 48, 713, 8.5, false);

  let currentY = 680;

  function sectionHeader(title) {
    currentY -= 5;
    addText(title.toUpperCase(), 45, currentY, 12, true);
    addLine(45, currentY - 4, 567, currentY - 4, 1.2, '0.54 0.36 0.96'); // Purple accent line
    currentY -= 18;
  }

  // EDUCATION
  sectionHeader('Education');
  addText('Bachelor of Engineering (B.E.) in Computer Science & Engineering (AI & ML)', 45, currentY, 10, true);
  addText('2024 - 2028 (Expected)', 460, currentY, 9, false);
  currentY -= 13;
  addText('AJ Institute of Engineering and Technology, Mangalore', 45, currentY, 9.5, false);
  currentY -= 12;
  addText('Specialization in Artificial Intelligence & Machine Learning', 55, currentY, 8.5, false);
  currentY -= 20;

  // TECHNICAL SKILLS
  sectionHeader('Technical Skills');
  addText('Programming Languages:', 45, currentY, 9.5, true);
  addText('Python, C, JavaScript, PHP', 190, currentY, 9.5, false);
  currentY -= 14;
  addText('AI & Machine Learning:', 45, currentY, 9.5, true);
  addText('Artificial Intelligence, Machine Learning, Text Preprocessing, TF-IDF, Cosine Similarity', 190, currentY, 9.5, false);
  currentY -= 14;
  addText('Web Technologies:', 45, currentY, 9.5, true);
  addText('HTML, CSS, JavaScript, Responsive UI/UX Design', 190, currentY, 9.5, false);
  currentY -= 14;
  addText('Database & Backend:', 45, currentY, 9.5, true);
  addText('DBMS, MySQL, Relational Database Modeling', 190, currentY, 9.5, false);
  currentY -= 14;
  addText('Tools & Environments:', 45, currentY, 9.5, true);
  addText('Gradio, XAMPP, VS Code, Git / GitHub', 190, currentY, 9.5, false);
  currentY -= 22;

  // PROJECTS
  sectionHeader('Key Projects');

  // Project 1
  addText('1. Language Translation Tool', 45, currentY, 10, true);
  addText('Python, Artificial Intelligence, Machine Learning', 360, currentY, 8.5, false);
  currentY -= 13;
  addText('- Developed a Python-based language translation system leveraging AI and ML techniques.', 55, currentY, 9, false);
  currentY -= 12;
  addText('- Implemented multilingual text processing pipelines for accurate sentence interpretation.', 55, currentY, 9, false);
  currentY -= 18;

  // Project 2
  addText('2. General FAQ Chatbot', 45, currentY, 10, true);
  addText('Python, NLP, TF-IDF, Cosine Similarity, Gradio', 335, currentY, 8.5, false);
  currentY -= 13;
  addText('- Engineered an intelligent FAQ query-answering chatbot utilizing comprehensive text preprocessing.', 55, currentY, 9, false);
  currentY -= 12;
  addText('- Computed query relevance using TF-IDF vectorization and cosine similarity matching algorithms.', 55, currentY, 9, false);
  currentY -= 12;
  addText('- Built an interactive web user interface with Gradio for seamless query testing and real-time responses.', 55, currentY, 9, false);
  currentY -= 18;

  // Project 3
  addText('3. Blood Management System', 45, currentY, 10, true);
  addText('PHP, MySQL, XAMPP, HTML, CSS, JavaScript', 345, currentY, 8.5, false);
  currentY -= 13;
  addText('- Designed a full-featured web-based blood donor and inventory management portal.', 55, currentY, 9, false);
  currentY -= 12;
  addText('- Created relational database schemas in MySQL to maintain donor records, requests, and blood availability.', 55, currentY, 9, false);
  currentY -= 12;
  addText('- Built responsive user interfaces with HTML/CSS and JavaScript connected to a PHP backend.', 55, currentY, 9, false);
  currentY -= 22;

  // CERTIFICATIONS
  sectionHeader('Certifications & Training');
  addText('Infosys Springboard Certification', 45, currentY, 10, true);
  currentY -= 13;
  addText('- Certified courses in Python programming, AI/ML fundamentals, and emerging technologies.', 55, currentY, 9, false);
  currentY -= 20;

  // LANGUAGES
  sectionHeader('Languages');
  addText('English (Professional Working)  |  Kannada (Native)  |  Hindi (Conversational)', 45, currentY, 9.5, false);

  const stream = content.join('\n');
  const streamLength = Buffer.byteLength(stream);

  // Construct valid PDF document
  const objects = [];
  
  // 1 0 obj: Catalog
  objects.push('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj');
  
  // 2 0 obj: Pages
  objects.push('2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj');
  
  // 3 0 obj: Page
  objects.push('3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >>\nendobj');
  
  // 4 0 obj: Contents stream
  objects.push(`4 0 obj\n<< /Length ${streamLength} >>\nstream\n${stream}\nendstream\nendobj`);
  
  // 5 0 obj: Font F1 (Helvetica)
  objects.push('5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj');
  
  // 6 0 obj: Font F2 (Helvetica-Bold)
  objects.push('6 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj');

  let pdfOutput = '%PDF-1.4\n';
  const xrefOffsets = [0];

  for (const obj of objects) {
    xrefOffsets.push(pdfOutput.length);
    pdfOutput += obj + '\n';
  }

  const xrefOffset = pdfOutput.length;
  pdfOutput += 'xref\n';
  pdfOutput += `0 ${objects.length + 1}\n`;
  pdfOutput += '0000000000 65535 f \n';
  
  for (let i = 1; i <= objects.length; i++) {
    const offsetStr = String(xrefOffsets[i]).padStart(10, '0');
    pdfOutput += `${offsetStr} 00000 n \n`;
  }

  pdfOutput += 'trailer\n';
  pdfOutput += `<< /Size ${objects.length + 1} /Root 1 0 R >>\n`;
  pdfOutput += 'startxref\n';
  pdfOutput += `${xrefOffset}\n`;
  pdfOutput += '%%EOF';

  fs.writeFileSync(outputPath, pdfOutput, 'binary');
  console.log(`PDF successfully created at: ${outputPath}`);
}

createPDF(path.join(__dirname, '../assets/docs/Manasa_Kulal_Resume.pdf'));
